import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detect-location',
  templateUrl: './detect-location.component.html',
  styleUrls: ['./detect-location.component.css']
})
export class DetectLocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

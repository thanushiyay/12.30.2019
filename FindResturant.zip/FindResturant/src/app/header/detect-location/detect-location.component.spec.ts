import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetectLocationComponent } from './detect-location.component';

describe('DetectLocationComponent', () => {
  let component: DetectLocationComponent;
  let fixture: ComponentFixture<DetectLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetectLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetectLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

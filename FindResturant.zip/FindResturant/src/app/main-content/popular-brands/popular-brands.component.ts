import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popular-brands',
  templateUrl: './popular-brands.component.html',
  styleUrls: ['./popular-brands.component.css']
})
export class PopularBrandsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

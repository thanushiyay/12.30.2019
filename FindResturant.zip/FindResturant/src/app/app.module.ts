import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainContentComponent } from './main-content/main-content.component';
import { SideNavContentComponent } from './main-content/side-nav-content/side-nav-content.component';
import { PopularBrandsComponent } from './main-content/popular-brands/popular-brands.component';
import { CarouselContentComponent } from './main-content/carousel-content/carousel-content.component';
import { HeaderComponent } from './header/header.component';
import { SearchByTimeComponent } from './main-content/search-by-time/search-by-time.component';
import {SearchComponent} from './header/search/search.component';
import {SignInComponent}  from './header/sign-in/sign-in.component';
import {CartComponent} from './header/cart/cart.component';
import {DetectLocationComponent} from './header/detect-location/detect-location.component';
import {HeaderLogoComponent} from './header/header-logo/header-logo.component';
import {NotificationsComponent}  from './header/notifications/notifications.component';
import { CarouselModule } from 'ngx-owl-carousel-o';
@NgModule({
  declarations: [
    AppComponent,
    MainContentComponent,
    SideNavContentComponent,
    PopularBrandsComponent,
    CarouselContentComponent,
    HeaderComponent,
    SearchByTimeComponent,
    SearchComponent,
    SignInComponent,
    CartComponent,
    DetectLocationComponent,
    HeaderLogoComponent,
    NotificationsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CarouselModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
